const express = require('express');
const multer = require('multer');
const { signup, signin, signout } = require('../controllers/auth');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/images');
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});
const upload = multer({ storage: storage });

const router = express.Router();

router.post('/signup', upload.single('photo'), signup);
router.post('/signin', signin);
router.get('/signout', signout);

module.exports = router;
