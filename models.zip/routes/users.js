const express = require('express');
const {
  getUsers,
  getUserProfile,
  addFollowing,
  addFollower,
  removeFollowing,
  removeFollower,
} = require('../controllers/users');
const { checkToken } = require('../controllers/auth');

const router = express.Router();

router.get('/users', checkToken, getUsers);
router.get('/profile/:id', checkToken, getUserProfile);
router.post('/user/follow/:id', checkToken, addFollowing, addFollower);
router.delete(
  '/user/unfollow/:id',
  checkToken,
  removeFollowing,
  removeFollower
);

module.exports = router;
