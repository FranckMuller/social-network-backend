const express = require('express');
const { updateUserProfile } = require('../controllers/profile');
const { checkToken } = require('../controllers/auth');

const router = express.Router();

router.put('/profile', checkToken, updateUserProfile);

module.exports = router;
