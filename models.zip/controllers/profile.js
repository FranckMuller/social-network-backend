const User = require('./../models/user');

exports.updateUserProfile = (req, res) => {
  const entries = Object.keys(req.body.userData);
  const updates = {};
  for (let i = 0; i < entries.length; i++) {
    updates[entries[i]] = Object.values(req.body.userData)[i];
  }
  User.findByIdAndUpdate(req.auth.id, { $set: updates }, (err, success) => {
    return res.status(200).json({
      updates,
      resultCode: 0,
    });
  });
};
