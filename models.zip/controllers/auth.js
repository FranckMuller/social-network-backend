const User = require('../models/user');
const jwt = require('jsonwebtoken');
const expressJwt = require('express-jwt');
const dotenv = require('dotenv');
const formidable = require('formidable');
const fs = require('fs');

dotenv.config();

exports.signup = async (req, res) => {
  const userExists = await User.findOne({
    email: req.body.email,
  });

  if (userExists) {
    return res.status(403).json({
      error: 'Email already taken!',
    });
  }

  let userData = req.body;
  userData = {
    ...userData,
    photo: `http://localhost:8080/images/${req.file.filename}`,
  };
  console.log(userData);
  const user = await new User(userData);

  await user.save();

  const accessToken = jwt.sign(
    {
      id: user.id,
    },
    process.env.JWT_SECRET
  );

  res.cookie('t', accessToken, {
    expire: new Date() + 10000000,
  });

  const authData = {
    accessToken: accessToken,
    id: user.id,
    name: user.name,
    surname: user.surname,
    email: user.email,
  };

  res.status(200).json(authData);
};

exports.signin = (req, res) => {
  const { email, password } = req.body;

  User.findOne({ email: email }, (err, user) => {
    if (err || !user || !user.authenticate(password)) {
      return res.status(404).json({
        errors: ['неверный email или пароль'],
        resultCode: 1,
      });
    }

    const accessToken = jwt.sign(
      {
        id: user.id,
      },
      process.env.JWT_SECRET
    );

    res.cookie('t', accessToken, {
      expire: new Date() + 10000000,
    });

    const authData = {
      accessToken: accessToken,
      id: user.id,
      name: user.name,
      surname: user.surname,
      email: user.email,
    };

    return res.status(200).json(authData);
  });
};

exports.signout = (req, res) => {
  res.clearCookie('t');
  return res.status(200).json({
    message: 'Sign out success',
    resultCode: 0,
  });
};

exports.checkToken = expressJwt({
  secret: process.env.JWT_SECRET,
  userProperty: 'auth',
});
